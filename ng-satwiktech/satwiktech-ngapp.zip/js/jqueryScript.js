function showhidemenu() { 
$('.dropdown-toggle').dropdown('toggle');
 }

 function showslidermenu() {
     $('.sidebar-nav-wrapper').toggleClass('openclosemenu');
     $('.mainbody').toggleClass('openclosemenu');
 }